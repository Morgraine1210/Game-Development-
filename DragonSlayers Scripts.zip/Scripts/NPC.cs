﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NPC : MonoBehaviour {
    //This script controls the AI behavioyr and "states" going from a passive patrol of 4 points to a chase should it see our player and back to patrol when we get out of range.
    public Transform position1;//
    public Transform position2;//These vars correspond to the empty game objects inside the game that the NPC recognizes as the milestones for his patrol.
    public Transform position3;//
    public Transform position4;//
    public Transform playerposition;//This is how the NPC knows where we are and then with given distances knows if we are close enough to chase or return to patrol.
    public Transform playerposition2;
    public Transform playerposition3;
    public Transform playerposition4;
    public GameObject healthBar;
    float stunnedTime;
    public float startStunTime;
    public float PlayerDetectDist;//This is the distance it knows as "Chase inside this range".
    public float PlayerLostDist;//This is the distance that it should return back to patrol.

    public float NpcSpeed;

    public float MaxHP = 100f;
    public float curHP;
    public float damage = 25f;
    public GameObject Player1;
    [SerializeField]
    private NavMeshAgent enemy;//This is serialized to drag and drop the navmesh for the agent.

    //At the start of the game we retrieve the baked nav mesh for our NPC.
    void Start()
    {
        NpcSpeed = GetComponent<NavMeshAgent>().speed;
        playerposition = GameObject.FindGameObjectWithTag("Player").transform;
      //  playerposition2 = GameObject.FindGameObjectWithTag("Player").transform;
        curHP = MaxHP;
        enemy = gameObject.GetComponent<NavMeshAgent>();
    }

    // This ifs control the priority for our NPC behaviour , it tells him the position of our player and then what the NPC should do as a action depending on the two distance variables it knows.
    //Chasing us if inside the chase range and leaving us be when we get out of the lost distance forcing the NPC to go back to patrol position 1.
    void FixedUpdate()
    {
        if (stunnedTime <= 0)
        {
           NpcSpeed = GetComponent<NavMeshAgent>().speed=5f;
        }
        else
        {
            NpcSpeed = GetComponent<NavMeshAgent>().speed=0f;
            stunnedTime -= Time.deltaTime;
        }
        if (Vector3.Distance(transform.position, playerposition.position) <= PlayerDetectDist)
        {
            enemy.SetDestination(playerposition.position);

            if (Vector3.Distance(transform.position, playerposition.position) >= PlayerLostDist && Vector3.Distance(transform.position, playerposition.position) <= PlayerDetectDist)
            {
                enemy.SetDestination(position1.position);
            }
        }
    }
    //This is the order the NPC patrols , always from 1 -> 2 -> 3 -> 4.
    void OnTriggerEnter(Collider other)
    {
        //{
        //    if (other.tag == "pos1")
        //    {
        //        enemy.SetDestination(position2.position);
        //    }
        //    if (other.tag == "pos2")
        //    {
        //        enemy.SetDestination(position3.position);
        //    }
        //    if (other.tag == "pos3")
        //    {
        //        enemy.SetDestination(position4.position);
        //    }
        //    if (other.tag == "pos4")
        //    {
        //        enemy.SetDestination(position1.position);
        //    }
        //}
        if (other.gameObject.tag=="Player")
        {
            //TakeDamage();
        }

    }
   public  void TakeDamage(float damage)
    {
        stunnedTime = startStunTime;
        curHP -= damage;
        Debug.Log("I got smacked");
        if (curHP <= 0)
        {
            Destroy(enemy);
        }
        float calc_Health = curHP / MaxHP;
        SetHealthBar(calc_Health);
    }
    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}
