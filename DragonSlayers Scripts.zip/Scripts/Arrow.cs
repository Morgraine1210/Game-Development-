﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Arrow : MonoBehaviour
{
    public float damage;
    RaycastHit hitInfo;
    public LayerMask solid;
    public GameObject Player2;
    public float speed;
    public float distance;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // hitInfo = Physics.Raycast(transform.position, transform.TransformDirection(Vector3.forward), out hitInfo, distance);
        //if (hitInfo.collider != null)
        //{
        //    if (hitInfo.collider.CompareTag("Enemy"))
        //    {
        //        Debug.Log("Ranged Hit!");
        //}
            //DestroyArrow();
        //}
        transform.Translate(Vector3.forward * speed * Time.deltaTime);
        // transform.Translate(transform.LookAt(Player2.GetComponentInChildren<meleePos>().transform) * speed * Time.deltaTime);
    }
    void DestroyArrow()
    {
        Destroy(gameObject);
    }
    void OnTriggerEnter(Collider other)
    {
        if((other.gameObject.tag == "Enemy"))
        {
            Debug.Log("Ranged Hit!");
            other.GetComponent<NPC>().TakeDamage(damage);
            DestroyArrow();
        }
    }
}
