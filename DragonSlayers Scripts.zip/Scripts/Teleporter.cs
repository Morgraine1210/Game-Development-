﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Teleporter : MonoBehaviour
{
    public Transform TeleportPos;  
    private void OnTriggerEnter(Collider other)
    {
        Debug.Log("Whoops you are in the boss now!");
        other.transform.position = TeleportPos.position; 
    }
}
