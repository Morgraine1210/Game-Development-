﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;

public class Player1Stats : MonoBehaviour
{
    public Animator KnightAnimator;
    public GameObject healthBar;
    public float damage;
    public LayerMask Enemy;
    public Transform meleePos;
    public float meleeRange;
    public float damageTaken = 20f;
    public float MaxHP = 100f;
    public float CurHP;
    public GameObject Player1;
    void Start()
    {
        CurHP = MaxHP;
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (Input.GetButton("XButton")) //Player 1 (Green) attack with XButton Joystick1
        {
            KnightAnimator.SetBool("isAttacking", true);
            Collider[] DetectedEnemies = Physics.OverlapSphere(meleePos.position, meleeRange, Enemy);
            for (int i = 0; i < DetectedEnemies.Length; i++)
            {
                DetectedEnemies[i].GetComponent<NPC>().TakeDamage(damage);
            }
        }
        else
        {
            KnightAnimator.SetBool("isAttacking", false);
        }
    }

    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            TakeDamage();
          
        }
    }

    void TakeDamage()
    {
        CurHP -= damageTaken;
        if (CurHP <= 0 )
        {
            Destroy(Player1);
        }
        float calc_Health = CurHP / MaxHP;
        SetHealthBar(calc_Health);
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(meleePos.position, meleeRange);
    }
    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}
