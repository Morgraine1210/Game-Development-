﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Assigner : MonoBehaviour
{

    //private int JoyNum;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        
        
       for (int JoyNum = 1; JoyNum < 3; JoyNum++) // Checks the number of joysticks from 1 until 2
       {
                if (Mathf.Abs(Input.GetAxis("J" + JoyNum + "Horizontal")) > 0 || //J1 Horizontal OR J2 Horizontal
                    Mathf.Abs(Input.GetAxis("J" + JoyNum + "Vertical")) > 0)    // J2 Horizontal OR J2 Vertical
                {
                    Debug.Log("Joystick" + JoyNum + " is moved");//Check to see which joystick is moving
                }


       }
        

    }
   


}
