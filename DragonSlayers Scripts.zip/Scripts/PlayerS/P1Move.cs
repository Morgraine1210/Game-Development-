﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;




public class P1Move : MonoBehaviour
{
    //private List<int> AddPlayerController = new List<int>(2); //How to add player?

    public Animator KnightAnimator;
    public float moveSpeed;
   

    void Start()
    {

    }
    void Update()
    {
        Move();
    }

    
    
   

    private void Move()
    {

        float moveHorizontal = Input.GetAxisRaw("J1Horizontal");
        float moveVertical = Input.GetAxisRaw("J1Vertical");



        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
      


        transform.Translate(movement * moveSpeed * Time.deltaTime, Space.World);
        KnightAnimator.SetBool("isWalking", true);
        if (movement != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(movement);

        }
        else
        {
            KnightAnimator.SetBool("isWalking", false);
        }
    }

   
} 