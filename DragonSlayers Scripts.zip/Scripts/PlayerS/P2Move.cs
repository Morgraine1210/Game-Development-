﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;




public class P2Move : MonoBehaviour
{
    //private List<int> AddPlayerController = new List<int>(2); //How to add player?


    public float moveSpeed;
   

    void Start()
    {

    }
    void Update()
    {

        Move();
    }

    
    
   

    private void Move()
    {

        float moveHorizontal = Input.GetAxisRaw("J2Horizontal");
        float moveVertical = Input.GetAxisRaw("J2Vertical");



        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);
      


        transform.Translate(movement * moveSpeed * Time.deltaTime, Space.World);

        if (movement != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(movement);

        }
    }

   
} 