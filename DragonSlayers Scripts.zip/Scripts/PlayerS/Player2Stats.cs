﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player2Stats : MonoBehaviour
{
    public GameObject Arrow;
    public Transform arrowPoint;
    public GameObject healthBar;
    public float damageTaken = 20f;
    public float MaxHP = 180f;
    public float CurHP;
    public GameObject Player2;
    void Start()
    {
        CurHP = MaxHP;
    }
    
    // Update is called once per frame
    void FixedUpdate()
    {
        
        if (Input.GetButton("AButton")) //Player 2 (Red) attack with AButton Joystick2
        {
            Instantiate(Arrow, arrowPoint.position, transform.rotation);
        }
    }
   
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            TakeDamage();
        }
    }

    void TakeDamage()
    {
        CurHP -= damageTaken;
        if (CurHP <= 0)
        {
            Destroy(Player2);
        }
        float calc_Health = CurHP / MaxHP;
        SetHealthBar(calc_Health);
    }
    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}
