﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Destroyer : MonoBehaviour {
    /* This is attached to our Destroyer colliders on the center of each room and are tasked with
     * destroying any other SpawnPoints that collide with them , ensuring that each room only spawns 
     * as many other rooms as needed and dont double back or spawn multiple rooms on top of each other.
     */

	void OnTriggerEnter(Collider other){
        if (other.gameObject.tag == "SpawnPoint")
        {
            Destroy(other.gameObject);
        }
    }
}
