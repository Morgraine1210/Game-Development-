﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NPCV2 : MonoBehaviour
{
    public float NpcSpeed;
    public GameObject healthBar;
    float stunnedTime;
    public float startStunTime;
    public float MaxHP = 150f;
    public float curHP;
    public float damage = 25f;
    [SerializeField]
    private NavMeshAgent enemy;//This is serialized to drag and drop the navmesh for the agent.
    // Start is called before the first frame update
    void Start()
    {
        //NpcSpeed = gameObject.GetComponent<ChaseBehaviour>().speed;
        NpcSpeed = GetComponent<NavMeshAgent>().speed;
        curHP = MaxHP;
        enemy = gameObject.GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (stunnedTime <= 0)
        {
            //NpcSpeed = gameObject.GetComponent<ChaseBehaviour>().speed = 5f;
             NpcSpeed = GetComponent<NavMeshAgent>().speed = 5f;
        }
        else
        {
            //NpcSpeed = gameObject.GetComponent<ChaseBehaviour>().speed = 0f;
            NpcSpeed = GetComponent<NavMeshAgent>().speed = 0f;
            stunnedTime -= Time.deltaTime;
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
           // TakeDamage(damage);
        }
    }
        public void TakeDamage(float damage)
        {
            stunnedTime = startStunTime;
            curHP -= damage;
            Debug.Log("I got hit!");
            if (curHP <= 0)
            {
                Destroy(enemy);
            }
            float calc_Health = curHP / MaxHP;
            SetHealthBar(calc_Health);
        }
    
    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}