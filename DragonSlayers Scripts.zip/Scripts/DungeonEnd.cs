﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class DungeonEnd : MonoBehaviour
{   /*This just quits the game should either of the two players collide with it at the boss room and debugs 
    a message for in editor testing as well. This will be used to end a level and proceed to the next and take players to 
    the actual final boss room when applicable.
    */
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag =="Player1"|| other.gameObject.tag == "Player2")
        {
            Application.Quit();
            Debug.Log("You finished the dungeon!");
        }
    }

}
