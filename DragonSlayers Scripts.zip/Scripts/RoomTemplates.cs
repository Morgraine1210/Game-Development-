﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;

public class RoomTemplates : MonoBehaviour {

	public GameObject[] bottomRooms;
	public GameObject[] topRooms;
	public GameObject[] leftRooms;
	public GameObject[] rightRooms;
    public GameObject Teleporters;
	public GameObject closedRoom;

	public List<GameObject> rooms;
    public static UnityEvent bossSpawned = new UnityEvent();
	public float waitTime;
	private bool spawnedBoss;
	public GameObject boss;
    public int roomCount = 0;

	void Update(){

		if(waitTime <= 0 && spawnedBoss == false)
        {

			for (int i = 0; i < rooms.Count; i++)
            {
				if(i == rooms.Count-1){
					Instantiate(boss, rooms[i].transform.position, Quaternion.Euler(90,0,0) /*Quaternion.identity*/);
                    Instantiate(Teleporters,rooms[i].transform.position,Quaternion.identity);
					spawnedBoss = true;
                    bossSpawned.Invoke();
				}
			}
		} else {
			waitTime -= Time.deltaTime;
		}
	}
}
