﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEditor;

[CreateAssetMenu(fileName = "Settings", menuName = "Scriptable", order = 1)]
public class SettingsPlaceholder : ScriptableObject
{
    public int MaximumDungeonRooms;
    public static UnityEvent bossSpawned = new UnityEvent();
    public  bool spawnedBoss;
    public GameObject boss;
    public int roomCount = 0;

}
