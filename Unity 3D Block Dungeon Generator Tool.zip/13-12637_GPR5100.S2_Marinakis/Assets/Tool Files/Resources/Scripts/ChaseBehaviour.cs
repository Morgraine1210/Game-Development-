﻿using UnityEngine;

public class ChaseBehaviour : StateMachineBehaviour
{
    private Transform playerLoc;
    public float speed;
    public float turnSpeed;
    public float PlayerDetectDist;//This is the distance it knows as "Chase inside this range".
    public float PlayerLostDist;//This is the distance that it should return back to patrol.
    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {//Random "Dice" roll for the enemies to aquire their target
        int Player = Random.Range(1, 2);
        if (Player == 1)
        {
            playerLoc = GameObject.FindGameObjectWithTag("Player1").transform;
            Debug.Log("Chasing Knight");
        }
        else if (Player == 2)
        {
            playerLoc = GameObject.FindGameObjectWithTag("Player2").transform;
            Debug.Log("Chasing Archer");
        }
    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {//This handles the AI state change and proper rotation towards the target , also their stun function is called here
        //if (Vector3.Distance(animator.transform.position, playerLoc.position) <= PlayerDetectDist)
        //{
        //    animator.transform.position = Vector3.MoveTowards(animator.transform.position, playerLoc.position, speed * Time.deltaTime);
        //}
        animator.transform.position = Vector3.MoveTowards(animator.transform.position, playerLoc.position, speed * Time.deltaTime);
        Vector3 FacingDirection = (playerLoc.position - animator.transform.position).normalized;
        Quaternion EnemyLookAt = Quaternion.LookRotation(new Vector3(FacingDirection.x, 0f, FacingDirection.z));
        animator.transform.rotation = EnemyLookAt;
        NPCV2 script = animator.GetComponent<NPCV2>();
        if (script.DamageTaken == true)
        {
            speed = 0f;
             
        }
        if (script.stunnedTime <=0)
        {
            script.DamageTaken = false;
            speed = 2f;
        }
        
        //if (speed != 0)
        //{
        //    animator.transform.rotation = Quaternion.LookRotation(playerLoc.position * speed * Time.deltaTime);

        //}
        if (Vector3.Distance(animator.transform.position, playerLoc.position) >= PlayerDetectDist)
        {
            animator.SetBool("isChasing", false);
        }
        // ameObject.transform.LookAt(playerLoc);
    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
