﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{//This script handles the spawning of the enemies and their random spawn numbers also their position inside the room
    public GameObject SpawnEdge1;
    public GameObject SpawnEdge2;
    float Enemies = 0f;
    float Warlocks = 0f;
    Vector3 position;
    public Vector3 Middle;
    public Vector3 Size;
    float EnemyAmount = 0f;
    float WarlockAmount = 0f;
    public GameObject Enemy;
    public GameObject Warlock;
    // Start is called before the first frame update
    void Start()
    {
       // Vector3 position = new Vector3(Random.Range(-3.0f, 3.0f), 0, Random.Range(-3.0f, 3.0f));
        EnemyAmount = Random.Range(1, 10);
        WarlockAmount = Random.Range(1, 2);
        Debug.Log(EnemyAmount);
        //StartCoroutine(Spawner());
    }
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player1")
        {
            Debug.Log("Skeletons incoming!");
            StartCoroutine(Spawner());
        }
    }
    IEnumerator  Spawner()
    {   
        while(Enemies< EnemyAmount)
        {
            Instantiate(Enemy,SpawnEdge1.transform.position, Quaternion.identity);
            yield return new WaitForSeconds(0.1f);
            Enemies += 1;        
        }
        while (Warlocks < WarlockAmount)
        {
            Instantiate(Warlock, SpawnEdge1.transform.position, Quaternion.identity);
            yield return new WaitForSeconds(0.1f);
            Warlocks += 1;
        }
    }
}
