﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;




public class P1Move : MonoBehaviour
{
    public Animator KnightAnimator;
    public float moveSpeed;
   
    void Start()
    {

    }
    void Update()
    {
        Move();
    }
    private void Move()
    {
        // Joystick 1 movement
        float moveHorizontal = Input.GetAxisRaw("Horizontal");
        float moveVertical = Input.GetAxisRaw("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        transform.Translate(movement * moveSpeed * Time.deltaTime, Space.World);
        KnightAnimator.SetBool("isWalking", true);
        //Player face movement direction 
        if (movement != Vector3.zero)
        {
            transform.rotation = Quaternion.LookRotation(movement);
        }
        else
        {
            KnightAnimator.SetBool("isWalking", false);
        }
    }   
} 