﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;


public class Player1Stats : MonoBehaviour
{
    public float MeleeTimer = 5f;
    private float nextAttackTime = 0f;
    public Animator KnightAnimator;
    public GameObject healthBar;
    public float damage;
    public LayerMask Enemy;
    public Transform meleePos;
    public float meleeRange;
    public float damageTaken = 20f;
    public float MaxHP = 100f;
    public float CurHP;
    public GameObject Player1;
    

    void Start()
    {
        //CurHP = GetComponent<HelthbarHUD>().maxHealth;
        healthBar = GameObject.FindGameObjectWithTag("Player1HP");
        CurHP = MaxHP;
    }

    // Update is called once per frame
    void Update()
    {
        Ray MeleeRange = new Ray(meleePos.transform.position, transform.forward);
        RaycastHit hitnfo;

        if (Input.GetKeyDown(KeyCode.E) && Physics.Raycast(MeleeRange, out hitnfo, 4f, Enemy)) //Player 1  attack with XButton Joystick1
        {
            if (hitnfo.collider.tag == "Enemy")
            {
                NPCV2 Health = hitnfo.collider.GetComponent<NPCV2>();
                Health.TakeDamage(damage);
            }
            if (hitnfo.collider.tag == "Warlock")
            {
                WarlockNPC Health = hitnfo.collider.GetComponent<WarlockNPC>();
                Health.TakeDamage(damage);
            }
            Debug.DrawLine(MeleeRange.origin, hitnfo.point, Color.red);

            KnightAnimator.SetBool("isAttacking", true);
                //Collider[] DetectedEnemies = Physics.OverlapSphere(meleePos.position, meleeRange, Enemy);
                //for (int i = 0; i < DetectedEnemies.Length; i++)
                //{
                //    DetectedEnemies[i].GetComponent<NPCV2>().TakeDamage(damage);
                //Debug.Log("Attack connection made!");         
                //}
            }
            else
            {
            Debug.DrawLine(MeleeRange.origin, MeleeRange.origin + MeleeRange.direction * 4f, Color.green);
            KnightAnimator.SetBool("isAttacking", false);
            }
        
    }

  public  void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Enemy")
        {
            TakeDamage(); 
        }
        if (other.gameObject.tag == "HealthPotion")
        {
            if (CurHP >= MaxHP)
            {
                CurHP = MaxHP;
            }
            else
            {
                CurHP += 20f;
            }
           
            float calc_Health = CurHP / MaxHP;
            SetHealthBar(calc_Health);
            Debug.Log("I got healed!");
        }
    }

    public void TakeDamage()
    {
        CurHP -= damageTaken;
        if (CurHP <= 0 )
        {
            Destroy(Player1);
        }
         float calc_Health = CurHP / MaxHP;
        SetHealthBar(calc_Health);
    }
    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(meleePos.position, meleeRange);
    }
    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}
