﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class IdleBehaviour : StateMachineBehaviour
{//Idle state of the melee Skeleton enemy , handles targeting and access to other states.
    private Transform playerLoc;
    public float PlayerDetectDist;//This is the distance it knows as "Chase inside this range".
    public float PlayerLostDist;//This is the distance that it should return back to patrol.
    // OnStateEnter is called when a transition starts and the state machine starts to evaluate this state
    override public void OnStateEnter(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {
        int Player = Random.Range(1, 2);
        if (Player == 1)
        {
            playerLoc = GameObject.FindGameObjectWithTag("Player1").transform;
            Debug.Log("Chasing Knight");
        }
        else if (Player == 2)
        {
            playerLoc = GameObject.FindGameObjectWithTag("Player2").transform;
            Debug.Log("Chasing Archer");
        }
        //playerLoc = GameObject.FindGameObjectWithTag("Player").transform;

    }

    // OnStateUpdate is called on each Update frame between OnStateEnter and OnStateExit callbacks
    override public void OnStateUpdate(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

        if (Vector3.Distance(animator.transform.position, playerLoc.position) <= PlayerDetectDist)
        {
            animator.SetBool("isChasing", true);
        }
        
        //if (Input.GetKeyDown(KeyCode.Space))
        //{
        //    animator.SetBool("isChasing",true);
        //}

    }

    // OnStateExit is called when a transition ends and the state machine finishes evaluating this state
    override public void OnStateExit(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    {

    }

    // OnStateMove is called right after Animator.OnAnimatorMove()
    //override public void OnStateMove(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that processes and affects root motion
    //}

    // OnStateIK is called right after Animator.OnAnimatorIK()
    //override public void OnStateIK(Animator animator, AnimatorStateInfo stateInfo, int layerIndex)
    //{
    //    // Implement code that sets up animation IK (inverse kinematics)
    //}
}
