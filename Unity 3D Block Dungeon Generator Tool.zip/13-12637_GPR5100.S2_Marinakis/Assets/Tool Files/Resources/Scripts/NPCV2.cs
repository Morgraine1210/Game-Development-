﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;
using UnityEngine.Animations;

public class NPCV2 : MonoBehaviour
{//Base script of the melee Skeleton enemy , this handles the enemy stats damage and components
    public bool DamageTaken = false;
    public Animator SkeletonAnim;
    public GameObject Enemy;
    public GameObject enemydrops;
    public GameObject HealthPotion;
    public float NpcSpeed;
    public GameObject healthBar;
    public float stunnedTime;
    public float startStunTime;
    public float MaxHP = 150f;
    public float curHP;
    public float damage = 25f;
    [SerializeField]
    private NavMeshAgent enemy;//This is serialized to drag and drop the navmesh for the agent.
    // Start is called before the first frame update
    void Start()
    {
        curHP = MaxHP;
        enemy = gameObject.GetComponent<NavMeshAgent>();
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        if (stunnedTime <= 0)
        {
        //This takes action inside the ChaseBehaviour Script of the AI..
        }
        else
        {       
            stunnedTime -= Time.deltaTime;
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
           // TakeDamage(damage);
        }
    }
        public void TakeDamage(float damage)
        {
            DamageTaken = true;
            stunnedTime = startStunTime;
            curHP -= damage;
            Debug.Log("I got hit!");
            if (curHP <= 0)
            {
                
            int loot = Random.Range(1, 2);
            if (loot==1)
            {
                Instantiate(HealthPotion,transform.position,Quaternion.identity);
                Debug.Log("A Health Potion Dropped!");
            }
            Destroy(Enemy);
            }
            float calc_Health = curHP / MaxHP;
            SetHealthBar(calc_Health);
        }
    
    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}