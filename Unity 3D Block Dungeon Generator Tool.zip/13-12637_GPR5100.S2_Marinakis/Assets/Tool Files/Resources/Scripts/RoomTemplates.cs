﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.AI;
[ExecuteInEditMode]
public class RoomTemplates : MonoBehaviour {

    public SettingsPlaceholder dungeonSettings;
    //This handles the arrays for the rooms and the if the "Boss" has spawned or not to end the procedure
	public GameObject[] bottomRooms;
	public GameObject[] topRooms;
	public GameObject[] leftRooms;
	public GameObject[] rightRooms;
    public GameObject Teleporters;
	public GameObject closedRoom;
	public List<GameObject> rooms;
    public static UnityEvent bossSpawned = new UnityEvent();
	public float waitTime;
    public bool spawnedBoss;
	public GameObject boss;
    public int roomCount = 0;


    public void AddRoom()
    {
        if (roomCount == dungeonSettings.MaximumDungeonRooms)
        {
            return;
        }
        roomCount += 1;
    }
}
