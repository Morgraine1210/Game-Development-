﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;
using System.IO;

[CustomEditor(typeof(MapGenerator))]
public class MapGeneratorEditor : Editor
{
    // The custom editor script , this has the button functions and starts the generation it has references to the ScriptableObject and RoomTemplates for settings and also a method to clear the scene and
    //the dungeon GameObject when called. 
    public GameObject SavedDungeon;
    public int MaxRooms;
    public SettingsPlaceholder settings;
    private RoomTemplates SettingsReset;
    GameObject CreatedDungeon;
    public GameObject DungeonList;
    [SerializeField]
    public GameObject StartRoom;
    private void OnEnable()
    {
        SettingsReset = GameObject.FindGameObjectWithTag("Rooms").GetComponent<RoomTemplates>();
    }

    public override void OnInspectorGUI()
    {
        settings.MaximumDungeonRooms = EditorGUILayout.IntField("Maximum Amount of Rooms : ", settings.MaximumDungeonRooms);
        Physics.autoSimulation = false;
        Physics.Simulate(Time.fixedDeltaTime);
        base.OnInspectorGUI();
        if (GUILayout.Button("Generate Dungeon!"))
        {
            serializedObject.Update();
            CreatedDungeon = GameObject.Find("DungeonList");
            GameObject Dungeon = Instantiate(StartRoom, new Vector3(0, 0, 0), StartRoom.transform.rotation);
            Dungeon.transform.parent = GameObject.Find("DungeonList").transform;
        }
        if (GUILayout.Button("Save Dungeon!"))
        { 
            CreatedDungeon = GameObject.Find("DungeonList");
            PrefabUtility.SaveAsPrefabAsset(CreatedDungeon, "Assets/Saves/SavedDungeon.prefab");
        }
        if (GUILayout.Button("Load Dungeon!"))
        {
            Instantiate(SavedDungeon, new Vector3(0, 0, 0), Quaternion.identity);
        }
        if (GUILayout.Button("Reset Dungeon!"))
        {
            ClearChildren();
            SettingsReset.rooms = null;
            SettingsReset.rooms = new List<GameObject> { };
            SettingsReset.roomCount = 0;
            DestroyImmediate(GameObject.Find("Teleporter(Clone)"));
            DestroyImmediate(GameObject.Find("Boss(Clone)"));
            DestroyImmediate(GameObject.Find("Closed Wall"));
            DestroyImmediate(GameObject.Find("DungeonList(Clone)"));
            DestroyImmediate(GameObject.Find("SavedDungeon(Clone)"));
        }
        void ClearChildren()
        {
            GameObject DungeonList = GameObject.Find("DungeonList");
            var tempArray = new GameObject[DungeonList.transform.childCount];

            for (int k = 0; k < tempArray.Length; k++)
            {
                tempArray[k] = DungeonList.transform.GetChild(k).gameObject;
            }

            foreach (var child in tempArray)
            {
                DestroyImmediate(child);
            }
            Debug.Log(DungeonList.transform.childCount);
            int i = 0;

            GameObject[] allChildren = new GameObject[DungeonList.transform.childCount];

            foreach (Transform child in DungeonList.transform)
            {
                allChildren[i] = child.gameObject;
                i += 1;
            }

            foreach (GameObject child in allChildren)
            {
                DestroyImmediate(child.gameObject);
            }
            Debug.Log(DungeonList.transform.childCount);
        }
    }
}

