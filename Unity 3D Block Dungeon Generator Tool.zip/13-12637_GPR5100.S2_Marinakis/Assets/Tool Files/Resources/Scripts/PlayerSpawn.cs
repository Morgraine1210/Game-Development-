﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerSpawn : MonoBehaviour
{
    /*Code that on game start gets the location of the player spawn points and then proceed to instantiate
     * each player if applicable to their designated spawn location inside the randomly generated dungeon.
     * Each player is a prefab so on start the program accesses the Resources folder and pulls them out according to their name
     * and to make sure each one has a different method spawning them if needed. 
     */
    public GameObject spawnLocation;
    public GameObject spawnLocation2;
    public GameObject Player1;
    public GameObject Player2;
    private Vector3 respawnLocation;
    private Vector3 respawnLocation2;

    private void Start()
    {
        Player1 = (GameObject)Resources.Load("Player1", typeof(GameObject));
        spawnLocation = GameObject.FindGameObjectWithTag("PlayerSpawn");
       // spawnLocation2 = GameObject.FindGameObjectWithTag("PlayerSpawn2");
        respawnLocation = Player1.transform.position;
        SpawnPlayer1();        

    }
    private void SpawnPlayer1()
    {
       Player1 = GameObject.Instantiate(Player1, spawnLocation.transform.position, Quaternion.identity);
    }
}
