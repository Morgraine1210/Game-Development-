﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class HealthPotion : MonoBehaviour
{//Simple script for the collision of the potion
    public GameObject HealthPot;
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player1" || other.gameObject.tag == "Player2")
        {
            Destroy(HealthPot);
            Debug.Log("I got picked up!");
        }
    }
    }
