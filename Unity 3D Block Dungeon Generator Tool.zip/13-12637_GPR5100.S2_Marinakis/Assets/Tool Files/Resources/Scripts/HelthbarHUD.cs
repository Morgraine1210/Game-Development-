﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class HelthbarHUD : MonoBehaviour
{
    public Image circleBar;
    public Image bar;

    public float currentHealth = 100;
    public float maxHealth = 100;

    public float circlePercentage = 0.3f;

    private const float circleFillAmount = 0.75f;

    // Update is called once per frame
    void Update()
    {
        CircleFill();
        BarFill();
    }
    void CircleFill() 
    {
        float healthPercentage = currentHealth / maxHealth;
        float circleFill = healthPercentage / circlePercentage;

        circleFill *= circleFillAmount;

        circleFill = Mathf.Clamp(circleFill, 0, circleFillAmount);

        circleBar.fillAmount = circleFill;
    }
    void BarFill()
    {
        float circleAmount = circlePercentage * maxHealth;

        float extraHealth = currentHealth - circleAmount;
        float extraTotalHealth = maxHealth - circleAmount;

        float barFill = extraHealth / extraTotalHealth;

        barFill = Mathf.Clamp(barFill, 0, 1);

        bar.fillAmount = barFill;
    }
}
