﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

//[CustomEditor(typeof(SettingsPlaceholder))]
public class MapGeneratorEditor : EditorWindow
    {
        private Editor kek;
        public int MaxRooms;
        GameObject RoomtoSpawn;
        private RoomTemplates SettingsReset;
        public GameObject DungeonList;
        public SettingsPlaceholder settings;
    public SerializedObject settings2;

        [MenuItem("Dungeon Tools/Dungeon Generator")]
        public static void GenerationWindow()
        {
            GetWindow(typeof(MapGeneratorEditor));
        }
        private void OnEnable()
        {
        settings2 = new SerializedObject(settings);
        //kek = Editor.CreateEditor(settings);
        //RoomtoSpawn = GameObject.FindGameObjectWithTag("EntryRoom").gameObject;
        SettingsReset = GameObject.FindGameObjectWithTag("Rooms").GetComponent<RoomTemplates>();         
        }

        public void OnGUI()
        {
            //kek.OnInspectorGUI();
           //  settings2.MaximumDungeonRooms = EditorGUILayout.IntField("Maximum Dungeon Rooms", settings2.MaximumDungeonRooms);
            MaxRooms = EditorGUILayout.IntField("Maximum Dungeon Rooms",MaxRooms);
            //settings.MaximumDungeonRooms = MaxRooms;
            RoomtoSpawn = EditorGUILayout.ObjectField("Starting Room", RoomtoSpawn, typeof(GameObject), false) as GameObject;
            Physics.autoSimulation = false;
            Physics.Simulate(Time.fixedDeltaTime);
        

            if (GUILayout.Button("Generate Dungeon!"))
            {

                GameObject Dungeon = Instantiate(RoomtoSpawn, new Vector3(0, 0, 0), RoomtoSpawn.transform.rotation);
                //Dungeon.transform.parent = ((MonoBehaviour)target).transform;
                Dungeon.transform.parent = GameObject.Find("DungeonList").transform;
            
            }
            if (GUILayout.Button("Save Dungeon!"))
            {

            }
            if (GUILayout.Button("Load Dungeon!"))
            {

            }
            if (GUILayout.Button("Reset Dungeon!"))
            {
                //for (int i = DungeonList.transform.childCount - 1; i >= 0; i--)
                //{
                ClearChildren();
                // Transform Placeholder = DungeonList.transform.GetChild(i);
                //DestroyImmediate(Placeholder.GetChild(i).gameObject);
                //GameObject.DestroyImmediate(Placeholder.transform);
                //Placeholder.transform.parent = null;             
                //}
                SettingsReset.rooms = null;
                SettingsReset.rooms = new List<GameObject> { };
                SettingsReset.roomCount = 0;
            }
            void ClearChildren()
            {
                GameObject DungeonList = GameObject.Find("DungeonList");
                //var tempArray = new GameObject[DungeonList.transform.childCount];

                //for (int i = 0; i < tempArray.Length; i++)
                //{
                //    tempArray[i] = DungeonList.transform.GetChild(i).gameObject;
                //}

                //foreach (var child in tempArray)
                //{
                //    DestroyImmediate(child);
                //}
                Debug.Log(DungeonList.transform.childCount);
                int i = 0;

                GameObject[] allChildren = new GameObject[DungeonList.transform.childCount];

                foreach (Transform child in DungeonList.transform)
                {
                    allChildren[i] = child.gameObject;
                    i += 1;
                }

                foreach (GameObject child in allChildren)
                {
                    DestroyImmediate(child.gameObject);
                }
                Debug.Log(DungeonList.transform.childCount);
            }

        }
    }

