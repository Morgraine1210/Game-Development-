﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using UnityEngine.AI;


[ExecuteInEditMode]
public class RoomSpawner : MonoBehaviour
{
    public SettingsPlaceholder settings;
    //This script handles the spawning of the rooms for the dungeon , connecting the doors and checks for max rooms to spawn and also disables any overlapping spawns.
    public int openingDirection;
    /* 1 --> need bottom door
    // 2 --> need top door
    // 3 --> need left door
    // 4 --> need right door
   */
    private GameObject Destroyer;
    private const int MAX_ROOMS =5;
    private RoomTemplates templates;
	private int rand;
	public bool spawned = false;

	void OnEnable()
    {
        Physics.Simulate(Time.fixedDeltaTime);
        templates = GameObject.FindGameObjectWithTag("Rooms").GetComponent<RoomTemplates>();
        Spawn();
    }

	public void Spawn(){
        
        if (spawned == false && templates.roomCount <  settings.MaximumDungeonRooms){
            Collider[] col = Physics.OverlapBox(this.gameObject.transform.position, new Vector3(5, 5, 5), Quaternion.identity);
            foreach (Collider item in col)
            {
                if (item.gameObject.CompareTag("Destroyer"))
                {
                    this.gameObject.SetActive(false);
                    return;
                }
            }

            if (openingDirection == 1){
				// Need to spawn a room with a BOTTOM door.
				rand = Random.Range(0, templates.bottomRooms.Length);
                GameObject go = Instantiate(templates.bottomRooms[rand], transform.position, templates.bottomRooms[rand].transform.rotation);
                go.transform.parent = GameObject.Find("DungeonList").transform;
               spawned = true;
            } else if(openingDirection == 2){
				// Need to spawn a room with a TOP door.
				rand = Random.Range(0, templates.topRooms.Length);
                GameObject go = Instantiate(templates.topRooms[rand], transform.position, templates.topRooms[rand].transform.rotation);
                go.transform.parent = GameObject.Find("DungeonList").transform;
                spawned = true;
            } else if(openingDirection == 3){
				// Need to spawn a room with a LEFT door.
				rand = Random.Range(0, templates.leftRooms.Length);
                GameObject go = Instantiate(templates.leftRooms[rand], transform.position, templates.leftRooms[rand].transform.rotation);
                go.transform.parent = GameObject.Find("DungeonList").transform;
                spawned = true;
            } else if(openingDirection == 4){
				// Need to spawn a room with a RIGHT door.
				rand = Random.Range(0, templates.rightRooms.Length);
                GameObject go = Instantiate(templates.rightRooms[rand], transform.position, templates.rightRooms[rand].transform.rotation);
                go.transform.parent = GameObject.Find("DungeonList").transform;
                spawned = true;
            }
        }
	}
}
