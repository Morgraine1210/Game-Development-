﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Animations;

public class WarlockNPC : MonoBehaviour
{//This is the base stat script for the Warlock ranged enemy , handling its stats , speed , attack and targeting
    public GameObject Spell;
    public bool DamageTaken = false;
    public Animator WarlockAnim;
    public GameObject Enemy;
    public GameObject enemydrops;
    public GameObject HealthPotion;
    public GameObject healthBar;
    public float stunnedTime;
    public float startStunTime;
    public float MaxHP = 150f;
    public float curHP;
    public float damage = 25f;
    public Transform playerLoc;
    public float timebtwshots;
    public float startTimebtwshots;
    private void Awake()
    {
        
        int Player = Random.Range(1, 2);
        if (Player == 1)
        {
            playerLoc = GameObject.FindGameObjectWithTag("Player1").transform;
            Debug.Log("Chasing Knight");
        }
        else if (Player == 2)
        {
            playerLoc = GameObject.FindGameObjectWithTag("Player2").transform;
            Debug.Log("Chasing Archer");
        }

    }
    // Start is called before the first frame update
    void Start()
    {
       // Spell = GameObject.FindGameObjectWithTag("Spell").GetComponent<GameObject>() ;
        timebtwshots = startTimebtwshots;
        curHP = MaxHP;    
    }

    // Update is called once per frame
    void FixedUpdate()
    {
        //Vector3 FacingDirection = (playerLoc.position - WarlockAnim.transform.position).normalized;
        //Quaternion EnemyLookAt = Quaternion.LookRotation(new Vector3(FacingDirection.x, 0f, FacingDirection.z));
        //WarlockAnim.transform.rotation = EnemyLookAt;
        if (timebtwshots <= 0)
        {
            Instantiate(Spell, transform.position, Quaternion.identity);
            timebtwshots = startTimebtwshots;
        }
        else
        {
            timebtwshots -= Time.deltaTime;
        }
        if (stunnedTime <= 0)
        {
            //This takes action inside the ChaseBehaviour Script of the AI..
        }
        else
        {
            stunnedTime -= Time.deltaTime;
        }
    }
    void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.tag == "Player")
        {
            // TakeDamage(damage);
        }
    }
    public void TakeDamage(float damage)
    {
        DamageTaken = true;
        stunnedTime = startStunTime;
        curHP -= damage;
        Debug.Log("I got hit!");
        if (curHP <= 0)
        {
            int loot = Random.Range(1, 2);
            if (loot == 1)
            {
                Instantiate(HealthPotion, transform.position, Quaternion.identity);
                Debug.Log("A Health Potion Dropped!");
            }
            Destroy(Enemy);
        }
        float calc_Health = curHP / MaxHP;
        SetHealthBar(calc_Health);
    }

    public void SetHealthBar(float myHealth)
    {
        healthBar.transform.localScale = new Vector3(myHealth, healthBar.transform.localScale.y, healthBar.transform.localScale.z);
    }
}
